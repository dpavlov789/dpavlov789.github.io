<?php
require_once $_SERVER['DOCUMENT_ROOT'] . '/vendor/autoload.php';

use AppCore\User;
use League\Csv\SwapDelimiter;
use League\Csv\Reader;
use League\Csv\Writer;

$user = new User();
$user->UserTableClean();
$fileName = 'users.csv';
$reader = Reader::createFromPath($_SERVER["DOCUMENT_ROOT"] . '/upload/' . $fileName, 'r');
$reader->setHeaderOffset(0);
$records = $reader;

foreach ($records as $offset => $record) {
    $user->CreateUser($record['fio'],$record['table']);
}

