<?php

class  GetUser
{
    public function __construct()
    {
        echo 1;
    }


}