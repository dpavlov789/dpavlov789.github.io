<?php
require_once $_SERVER['DOCUMENT_ROOT'] . '/vendor/autoload.php';

use AppCore\User;
use League\Csv\SwapDelimiter;
use League\Csv\Reader;
use League\Csv\Writer;

//$dbConnect = mysqli_connect("localhost", "cf30462_cp2024", "8152G2Lz", "cf30462_cp2024");
//$methodQuery = mysqli_query($dbConnect, "DELETE FROM compliments");
//$fileName = 'compliments.csv';
//$reader = Reader::createFromPath($_SERVER["DOCUMENT_ROOT"] . '/upload/' . $fileName, 'r');
//$reader->setHeaderOffset(0);
//$records = $reader;
//
//foreach ($records as $offset => $record) {
//    $text= $record['text'];
//    $show = $record['show'];
//    $methodQuery = mysqli_query($dbConnect, "INSERT INTO  compliments (compliments_text, compliments_show) VALUES ('$text','$show')");
//}