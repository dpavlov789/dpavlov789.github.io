<?php
require_once $_SERVER['DOCUMENT_ROOT'] . '/vendor/autoload.php';

mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

use AppCore\User;

$user = new User();
?>
<!doctype html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="./assets/css/app.min.css?v10">
    <meta name="robots" content="noindex"/>

    <title>Корпоратив УК Кар Корп 2024</title>

</head>
<body>
<div class="bg-dark" style="margin-bottom: -2em">
    <header class="b-head">
        <img class="b-head__logo" src="./assets/img/logo.svg" alt="УК Кар Корп логотип">
    </header>
    <div class="compliment">
        <div class="compliment__title">
            Ваше предсказание <br> на 2025 год
        </div>

        <div class="box box_sm"></div>
        <div class="box box_md"></div>
        <div class="box box_lg"></div>
        <div class="compliment__text">

                <span>
                    <?php
                    $dbConnect = mysqli_connect("localhost", "cf30462_cp2024", "8152G2Lz", "cf30462_cp2024");
                    $methodQuery = mysqli_query($dbConnect, "SELECT * FROM compliments ORDER BY RAND() LIMIT 1");

                    while ($row = mysqli_fetch_row($methodQuery)) {
                        echo $row[1];
                    }
                    ?>
            </span>
        </div>

    </div>

</div>
<div class="vector-bg"></div>
<img style="display: block;position: relative; z-index: 2;max-width: 100%; width: 100%; margin: -70% auto 0 auto"
     src="./assets/img/el.png" alt="">


<script src="./assets/js/app.min.js?v10"></script>

</body>
</html>


