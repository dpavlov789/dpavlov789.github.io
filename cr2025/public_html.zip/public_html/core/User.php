<?php

namespace AppCore;
class  User
{
    public $dbConnect;

    public function __construct()
    {
        $this->dbConnect = mysqli_connect("localhost", "cf30462_cp2024", "8152G2Lz", "cf30462_cp2024");
        if ($this->dbConnect == false) {
            return false;
        } else {
            return true;
        }
    }

    public function GetList()
    {
        $result = [];
        $methodQuery = mysqli_query($this->dbConnect, "SELECT * FROM users ORDER BY user_fio");
        while ($row = mysqli_fetch_row($methodQuery)) {
            $user['id'] = $row[0];
            $user['fio'] = $row[1];
            $user['table'] = $row[2];
            $user['compliments'] = $row[3];

            array_push($result, $user);
        }
        return $result;
    }

    public function GetUser($fio)
    {
        $result = [];
        $methodQuery = mysqli_query($this->dbConnect, "SELECT * FROM `users` WHERE `user_fio` IN ('$fio')");
        if ($methodQuery->num_rows == 0) {
            echo "Пользователь с ФИО " . $fio . " не найден\n";
            return false;
        } else {
            while ($row = mysqli_fetch_row($methodQuery)) {
            $user['id'] = $row[0];
            $user['fio'] = $row[1];
            $user['table'] = $row[2];
            $user['compliments'] = $row[3];

            array_push($result, $user);
        }
        return $result;
        }
    }

    public function CreateUser($fio, $tableId)
    {
        $findUser = mysqli_query($this->dbConnect, "SELECT * FROM `users` WHERE `user_fio` IN ('$fio')");
        if (!$findUser->num_rows == 0) {
            echo "Пользователь с ФИО " . $fio . " уже существует\n";
            return false;
        } else {
            $methodQuery = mysqli_query($this->dbConnect, "INSERT INTO  users (user_fio, user_table) VALUES ('$fio','$tableId')");
            if ($methodQuery === false) {
                echo "Ошибка добавления " . $fio . "\n";
                return false;
            } else {
                echo "Пользователь " . $fio . " добавлен, стол " . $tableId . "\n";
                return true;
            }
        }
    }

    public function DeleteUser($fio)
    {
        $findUser = mysqli_query($this->dbConnect, "SELECT * FROM `users` WHERE `user_fio` IN ('$fio')");
        if ($findUser->num_rows == 0) {
            echo "Пользователь с ФИО " . $fio . " не найден\n";
            return false;
        } else {
            $methodQuery = mysqli_query($this->dbConnect, "DELETE FROM users WHERE user_fio='$fio'");
            echo "Пользователь с ФИО " . $fio . " удален\n";
            return true;
        }
    }

    public function UserTableClean()
    {
        $methodQuery = mysqli_query($this->dbConnect, "DELETE FROM users");
        if ($methodQuery === false) {
            echo "Ошибка при попытке очистить таблицу users";
            return false;
        } else {
            echo "Таблица users очищена";
            return true;
        }
    }
}