<?php
namespace AppCore;

class Compliments
{
    public $compliments;
    public $userId;
    public function __construct($userId = 'NULL'){
        $this->compliments = '';
        $this->userId = $userId;
    }

    public function Show()
    {

    }
}